export interface userToCreate {
  name: string,
  address: string,
  imgPath: string
}
